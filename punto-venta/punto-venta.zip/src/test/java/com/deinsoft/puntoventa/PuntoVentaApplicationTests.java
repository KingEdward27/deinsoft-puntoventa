package com.deinsoft.puntoventa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PuntoVentaApplicationTests {

	@Test
	void contextLoads() {
	}

}

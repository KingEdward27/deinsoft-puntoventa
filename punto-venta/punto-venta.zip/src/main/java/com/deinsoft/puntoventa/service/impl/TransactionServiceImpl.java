/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.deinsoft.puntoventa.service.impl;

import com.deinsoft.puntoventa.model.Detail;
import com.deinsoft.puntoventa.model.JsonData;
import com.deinsoft.puntoventa.repository.JdbcRepository;
import com.deinsoft.puntoventa.service.TransactionService;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
/**
 *
 * @author EDWARD-PC
 */
@Service
@Transactional
public class TransactionServiceImpl implements TransactionService{

    @Autowired
    JdbcRepository jdbcRepository;
    
    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED)
    public void saveTransaction(JsonData jsonData) {
        try {
            ObjectMapper oMapper = new ObjectMapper();
            jdbcRepository.create(jsonData.getTableName(),jsonData.getFilters());
            String idColumn = jdbcRepository.getColumnPk(jsonData.getTableName());
            int idValue = (int)jdbcRepository.selectMaxValueFromColumn(jsonData.getTableName(), idColumn);
//            Map<String, Object> map = oMapper.convertValue(result, Map.class);
            for (Detail detail : jsonData.getDetails()) {
                for (Map<String,Object> object : detail.getFilters()) {
                    object.put(detail.getRelatedBy(), idValue);
                    jdbcRepository.create(detail.getTableName(),object);
                }
                
            }
        } catch (Exception ex) {
            TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
            ex.printStackTrace();
        }
    }
    
}

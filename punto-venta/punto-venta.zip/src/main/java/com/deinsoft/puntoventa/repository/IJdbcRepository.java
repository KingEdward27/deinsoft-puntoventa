package com.deinsoft.puntoventa.repository;

import java.util.List;
import java.util.Map;

import com.deinsoft.puntoventa.model.MetaData;


public interface IJdbcRepository {
	List<MetaData> findAll(String tableName);
}
